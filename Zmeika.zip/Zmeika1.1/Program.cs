﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Zmeika1
{
    class Game
    {
        public static int ispeed; //Скорость игры
        public static void Main(string[] args)
        {
            StartGame(); //Первичные инициализации
            Move.k = Console.ReadKey(true);
            while (Move.k.Key != ConsoleKey.Escape)
            {
                Move.MoveBody();
                Thread.Sleep(ispeed);
                while (Console.KeyAvailable)
                {
                    Move.k = Console.ReadKey(true);
                }
                Food.EatFood();
                Move.DirMove();
                if (Move.count == 13) // Количество очков для победы
                {
                    Console.Clear();
                    Console.WriteLine("Победа!");
                    Console.ReadKey();
                    break;
                }
            }
            Thread.Sleep(1000);
            Environment.Exit(0);
        }
        public static void StartGame()
        {
            Console.SetWindowSize(50, 25);
            Console.WriteLine("Укажите скорость игры\n500 - минимальная\n50 - максимальная\nрекомендуемая - 250:");
            try
            {
                string speed = Console.ReadLine();
                ispeed = Convert.ToInt32(speed);
            }
            catch
            {
                Console.WriteLine("Неверное значение");
                Console.ReadKey();
                Thread.Sleep(1000);
                Environment.Exit(0);
            }
            if (ispeed > 500 || ispeed < 50)
            {
                Console.WriteLine("Неверное значение");
                Console.ReadKey();
                Thread.Sleep(1000);
                Environment.Exit(0);
            }
            Console.CursorVisible = false; // гасим курсор
            Console.Clear();
            Console.SetCursorPosition(15, 15);
            Console.Write((char)2);
            Map.PrintScore();
            Map.GenMap();
            Move.IniBody();
            Food.GenFood();
        }
        static int X = 40; //Ширина карты
        static int Y = 24; //Высота карты
        class Map
        {
            public static void GenMap()
            {
                xWalls(0, 0);
                xWalls(0, 24);
                yWalls(0, 0);
                yWalls(40, 0);
            }

            public static void xWalls(int x = 0, int y = 0)
            {
                for (x = 0; x <= Game.X; x++)
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write("#");
                }
            }
            public static void yWalls(int x = 0, int y = 0)
            {
                for (y = 0; y <= Game.Y; y++)
                {
                    Console.SetCursorPosition(x, y);
                    Console.Write("#");
                }
            }
            public static void PrintScore()
            {
                Console.SetCursorPosition(42, 2);
                Console.Write("Счет: " + (Move.count - 3));
            }
        }
        class Move
        {
            public static ConsoleKeyInfo k;
            public static int dir; //Направление движения
            public static int x = 15; //Координаты появления змейки
            public static int y = 15; //
            public static int dimx = 0; //Координата y
            public static int dimy = 1; //Координата x
            public static int inicount = 3; //Началный размер змейки
            public static int count = inicount; //Подсчет очков и длина змейки
            public static int maxcount = 30; //Максимальный размер змейки
            public static int[][] mas = new int[maxcount][]; //Тело змейки
            public static void IniBody()
            {
                if (count == inicount)
                    for (int i = 0; i < count + 1; i++)
                    {
                        mas[i] = new int[2];
                        mas[i][dimx] = x;
                        mas[i][dimy] = y;
                    }
                else
                    for (int i = count - 1; i < count + 1; i++)
                    {
                        mas[count] = new int[2];
                        mas[count][dimx] = mas[count - 1][dimx];
                        mas[count][dimy] = mas[count - 1][dimy];
                    }
            }
            public static void MoveBody()
            {
                for (int i = 0; i <= count; i++)
                {
                    Console.SetCursorPosition(mas[i][dimx], mas[i][dimy]);
                    if (i == count)
                        Console.Write((char)2);
                    else
                        Console.Write((char)3);
                    if (i > 0)
                    {
                        if (mas[i - 1][dimx] != mas[i][dimx])
                            mas[i - 1][dimx] = mas[i][dimx];
                        if (mas[i - 1][dimy] != mas[i][dimy])
                            mas[i - 1][dimy] = mas[i][dimy];
                    }
                    if (i == 0)
                    {
                        Console.SetCursorPosition(mas[i][dimx], mas[i][dimy]);
                        Console.Write(" ");
                    }
                }
                if (count > inicount)
                    for (int i = 3; i < count - 1; i++)
                    {
                        if (mas[count][dimx] == mas[count - i-2][dimx])
                            if (mas[count][dimy] == mas[count - i-2][dimy])
                            {
                                //count -= (i);
                                Console.Clear();
                                Console.WriteLine("Конец игры!");
                                Thread.Sleep(1000);
                                Console.ReadKey();
                                Environment.Exit(0);
                                break;
                            }
                    }
            }
            public static void DirMove()
            {
                switch (k.Key)
                {
                    case ConsoleKey.UpArrow:
                        if (dir != 2)
                        {
                            if (mas[count][dimy] != 1)
                                mas[count][dimy]--;
                            else
                                mas[count][dimy] = 23;
                            dir = 1;
                        }
                        else
                            goto case ConsoleKey.DownArrow;
                        break;
                    case ConsoleKey.DownArrow:
                        if (dir != 1)
                        {
                            if (mas[count][dimy] != 23)
                                mas[count][dimy]++;
                            else
                                mas[count][dimy] = 1;
                            dir = 2;
                        }
                        else
                            goto case ConsoleKey.UpArrow;
                        break;
                    case ConsoleKey.LeftArrow:
                        if (dir != 4)
                        {
                            if (mas[count][dimx] != 1)
                                mas[count][dimx]--;
                            else
                                mas[count][dimx] = 39;
                            dir = 3;
                        }
                        else
                            goto case ConsoleKey.RightArrow;
                        break;
                    case ConsoleKey.RightArrow:
                        if (dir != 3)
                        {
                            if (mas[count][dimx] != 39)
                                mas[count][dimx]++;
                            else
                                mas[count][dimx] = 1;
                            dir = 4;
                        }
                        else
                            goto case ConsoleKey.LeftArrow;
                        break;
                }
            }
        }
        class Food
        {
            static int x; //Координата появления еды x
            static int y; //Координата появления еды y
            public static void GenFood()
            {
                Random rnd = new Random();
                x = rnd.Next(1, 40);
                y = rnd.Next(1, 24);
                Console.SetCursorPosition(x, y);
                Console.Write((char)4);
            }
            public static void EatFood()
            {
                if (x == Move.mas[Move.count][Move.dimx])
                    if (y == Move.mas[Move.count][Move.dimy])
                    {
                        Move.count++;
                        Move.IniBody();
                        GenFood();
                        Map.PrintScore();
                        //if (Game.ispeed > 25)
                        //    Game.ispeed -= 25;
                        //else
                        //    Game.ispeed = 25;
                    }
            }
        }
    }
}

